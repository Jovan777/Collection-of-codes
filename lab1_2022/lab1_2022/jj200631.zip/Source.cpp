#include <iostream>
#include "flota.h"


using namespace std;



int main() {


	/*
	Pilot p("P", 150, true);
	Pilot p2("P2", 10);

	Pilot p11("P11", 100);
	Pilot p12("P12", 50);

	Pilot p31("P31", 200);
	Pilot p32("P32", 10);

	p.pisi();
	cout << endl;
	p2.pisi();

	Avion a1("JAT", 100);
	Avion a2("AIR", 200);
	Avion a3("Airplane7", 300);

	a1.setKap(&p);
	a1.setKop(&p2);

	a2.setKap(&p11);
	a2.setKop(&p12);

	a3.setKap(&p31);
	a3.setKop(&p32);

	Pilot* p3 = a1.getKap();
	Pilot* p4 = a1.getKop();

	cout << endl;
	p3->pisi();
	cout << endl;

	p4->pisi();
	cout << endl;
	p2.pisi();

	cout << endl;

	a1.pisi();
	cout << endl;
	cout << endl;
	cout << endl;
	
	Flota f1("Flota1");

	f1.dodaj(&a1);
	f1.dodaj(&a2);
	f1.dodaj(&a3);

	f1.pisi();
	cout << endl;

	Avion* pa = f1.getMaxA();
	pa->pisi();
	cout << endl;
	cout << "broj aviona : " << f1.numberOfPlanes() << endl;
	cout << "broj putnika : " << f1.brojP() << endl;
	*/


	





	return 0;
}